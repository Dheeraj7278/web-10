<?php
include("header.php");
?>
<div class="wrapper col1">
  <div id="container">
    <div id="content">
      <h1>Welcome to Online Hospital Management System</h1>
      <p>  The goal of the Doctor appointment SYSTEM
  System is to improve the efficiency of the health by reducing the overall time and cost used to create documents and retrieve information.
.</p>
      <p>The main feature of E-Knowledge in Doctor appointment system is to provide the browser to get appointments from a doctor through internet instead of going there and fixing an appointment..</p>
      <p>	Everyone needs to have Medical attention at any time. So we allow every user to register freely at any time..</p>
      <p>Doctor appointment System maintains patient�s prescriptions so that their medical details are always available in Internet, which will be more convenient for the patients. This will be more comfortable for the patient..</p>

      <div class="homecontent">
        <ul>
          <li>
            <h2>Book your Appointment through online   </h2>
            <p class="imgholder"><a href="patientappointment.php"><img src="images/appointment.png" alt="" style="width:286px;height:100px;" /></a></p>
          </li>
          <li class="last">
            <h2>Login Panel for existing users</h2>          
            <p class="imgholder"><a href="patientlogin.php"><img src="images/login.jpg" alt="" style="width:286px;height:100px;"  /></a></p>
          </li>
        </ul>
        <div class="clear"></div>
      </div>
    </div>
   
    <div class="clear"></div>
  </div>
</div>
<?php
include("footer.php");
?>